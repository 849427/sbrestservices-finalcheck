package com.cognizant.moviecruiser.service.exception;

public class MovieNotFoundException extends Exception {

	public MovieNotFoundException(String msg) {
		super(msg);
	}

}
