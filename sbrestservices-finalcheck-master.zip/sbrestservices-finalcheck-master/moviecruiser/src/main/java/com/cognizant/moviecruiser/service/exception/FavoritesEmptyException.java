package com.cognizant.moviecruiser.service.exception;

public class FavoritesEmptyException extends Exception {

	public FavoritesEmptyException(String msg) {
		super(msg);
	}

}
